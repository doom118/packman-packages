class Data(object):
    """
    Task handlers should return instances of that class.
    """

    def __init__(self, name, item):
        self.name = name
        self.item = item
